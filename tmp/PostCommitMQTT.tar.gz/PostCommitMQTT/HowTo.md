# MqttPublisher

## Overview

`MqttPublisher` is a Java utility class that publishes JSON messages to an MQTT broker using the Eclipse Paho MQTT client library.

The class:

1. Loads MQTT configuration from a file.
2. Creates an MQTT client connection.
3. Optionally derives the MQTT topic from values contained in the JSON payload.
4. Publishes the JSON message to the MQTT broker.
5. Disconnects from the broker.

The class is designed to be invoked from external applications (such as Informix UDRs) through the static method:

```java
MqttPublisher.Json2Mqtt(jsonString);
```

---

## Dependencies

### MQTT Client

- Eclipse Paho MQTT Client

```xml
org.eclipse.paho.client.mqttv3
```

### JSON Processing

- JSON-Java (`org.json`)

```xml
org.json.JSONObject
```

---

## Configuration File

The application loads its configuration from:

```text
$INFORMIXDIR/etc/mqtt.conf
```

### Example Configuration

```properties
brokerUrl=tcp://mqtt.example.com:1883
clientId=
username=myuser
password=mypassword
topic=sensors/%device
debug=true
```

---

## Configuration Parameters

| Property | Description |
|-----------|-------------|
| `brokerUrl` | MQTT broker URL. |
| `clientId` | MQTT client identifier. If empty, the hostname is used. |
| `username` | MQTT username. |
| `password` | MQTT password. |
| `topic` | MQTT topic where messages will be published. |
| `debug` | Enables debug logging when set to `true`. |

---

## Program Flow

### 1. Entry Point

```java
public static void main(String[] args)
```

Publishes a test JSON message:

```json
{
  "message": "Cadena de prueba ejecutada desde main()"
}
```

This method is primarily intended for testing.

---

### 2. Publish JSON Message

```java
public static void Json2Mqtt(String jsonString)
```

Main public API used to publish a JSON payload.

#### Steps

1. Load configuration.
2. Determine client ID.
3. Connect to MQTT broker.
4. Build final topic.
5. Publish JSON payload.
6. Disconnect.

#### Parameters

| Parameter | Description |
|------------|-------------|
| `jsonString` | JSON payload to publish. |

Example:

```java
String json =
    "{\"device\":\"sensor01\",\"temperature\":25}";

MqttPublisher.Json2Mqtt(json);
```

---

## Dynamic Topic Construction

The configured topic may contain placeholders prefixed with `%`.

Example configuration:

```properties
topic=sensors/%device
```

Input JSON:

```json
{
  "device":"sensor01",
  "temperature":25
}
```

Resulting MQTT topic:

```text
sensors/sensor01
```

### Multiple Placeholders

Configuration:

```properties
topic=plant/%site/%device
```

JSON:

```json
{
  "site":"factory1",
  "device":"sensor01"
}
```

Generated topic:

```text
plant/factory1/sensor01
```

---

## MQTT Connection

The class uses `MqttConnectOptions` with the following settings:

```java
connOpts.setCleanSession(true);
```

If a password is configured:

```java
connOpts.setUserName(username);
connOpts.setPassword(password.toCharArray());
```

---

## Quality of Service (QoS)

The publisher uses a fixed QoS level:

```java
private static final int DEFAULT_QOS_LEVEL = 0;
```

Meaning:

- Fire-and-forget delivery.
- No delivery acknowledgment required.
- Lowest network overhead.

---

## Client ID Handling

If `clientId` is not configured:

```java
clientId = InetAddress.getLocalHost().getHostName();
```

The local hostname becomes the MQTT client identifier.

If hostname retrieval fails:

```java
clientId = "defaultClientId";
```

is used as a fallback.

---

## Debug Logging

Debug output is controlled by:

```properties
debug=true
```

When enabled, messages such as:

```text
Connecting to broker: tcp://mqtt.example.com:1883
Connected
Message published to topic: sensors/sensor01 with QoS: 0
Disconnected
```

are printed to standard output.

---

## Error Handling

### Configuration Errors

If the configuration file cannot be loaded:

```text
Error loading configuration file: ...
```

is printed to standard error.

### MQTT Errors

Connection and publishing errors are caught and reported as:

```text
MQTT Exception: ...
```

### Topic Substitution Errors

Errors during JSON parsing or topic expansion are reported as:

```text
ConstructFullTopic Exception: ...
```

---

## Example

### Configuration

```properties
brokerUrl=tcp://broker.example.com:1883
clientId=
username=mqttuser
password=secret
topic=devices/%device/events
debug=true
```

### JSON Payload

```json
{
  "device":"sensor01",
  "event":"temperature",
  "value":25.7
}
```

### Generated Topic

```text
devices/sensor01/events
```

### Published Message

```json
{
  "device":"sensor01",
  "event":"temperature",
  "value":25.7
}
```

---

## Notes and Limitations

1. A new MQTT connection is created for every published message.
2. Only top-level JSON fields can be used as topic placeholders.
3. Missing placeholder values are not validated and remain unchanged in the topic.
4. QoS is hardcoded to `0`.
5. Retained MQTT messages are not supported.
6. SSL/TLS configuration depends entirely on the broker URL and JVM configuration.
7. The class is implemented entirely with static methods and static configuration variables, making it simple to invoke from Informix Java UDRs.

