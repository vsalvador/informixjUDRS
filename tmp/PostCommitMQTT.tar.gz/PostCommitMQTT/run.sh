
java -cp ".:org.eclipse.paho.client.mqttv3-1.2.5.jar:json-20210307.jar" MqttPublisher
