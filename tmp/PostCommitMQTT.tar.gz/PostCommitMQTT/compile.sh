javac --release 11 -cp ".:lib/org.eclipse.paho.client.mqttv3-1.2.5.jar:lib/json-20210307.jar:lib/ifxjdbc.4.50.13.jar" MqttPublisher.java

cp MqttPublisher.class $INFORMIXDIR/extend/krakatoa

