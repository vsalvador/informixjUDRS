MQTT jar client from: https://repo1.maven.org/maven2/org/eclipse/paho/org.eclipse.paho.client.mqttv3/1.2.5/

# Check your krakatoa environment is working properly

As we are not using embeded jre and using standard Java JDK,
check that jre is linked to proper folder executing:

```bash
$INFORMIXDIR/extend/krakatoa/jre/bin/java -version
```

and Configure $INFORMIXDIR/etc/$ONCONFIG parameters with this values
JVPJAVAHOME              $INFORMIXDIR/extend/krakatoa/jre
JVPJAVAVM                jvm
JVPJAVALIB               /lib/server


Those with sharp eyes will note that having JVPJAVAVM=jvm does not seem to match the description in the onconfig comments "Path relative to JVPJAVAHOME that points to the JVM shared library (libjvm.so or jvm.dll)".  Also, JVPJAVALIB=/lib/server does not match the description of "Path relative to JVPJAVAHOME ...".

Regardless of those inconsistencies, I now can run 

SELECT UUID() FROM sysmaster:sysdual


# Installation

## Configure Krakatoa CLASSPATH

Edit $INFORMIXDIR/etc/$ONCONFIG and setup JVPCLASSPATH parameter to include the jars and the classes

```
JVPCLASSPATH    $INFORMIXDIR/extend/krakatoa/krakatoa.jar:$INFORMIXDIR/jars/json-20210307.jar:$INFORMIXDIR/jars/org.eclipse.paho.client.mqttv3-1.2.5.jar:$INFORMIXDIR/extend/krakatoa/.
```

Copy the mqtt.conf file to $INFORMIXDIR/etc/mqtt.conf
Edit mqtt.conf file and set up the proper parameters to connect to MQTT broker

## Install jar

DATABASE xxx;
EXECUTE PROCEDURE sqlj.install_jar ('file:$INFORMIXDIR/extend/krakatoa/MqttPublisher.jar', 'MqttPublisher', 1);


## Alternative manual Procedure installation

Using dbaccess, connecto to the database which tables you want to replicate and define the replication procedure:

```sql
DROP PROCEDURE IF EXISTS json2mqtt;

CREATE PROCEDURE json2mqtt(lvarchar)
  external name 'MqttPublisher.Json2Mqtt(java.lang.String)'
  language java;

grant execute on procedure json2mqtt(lvarchar) to public;
```

You can test if everything works smoothly by executing the procedure and checking than the message is published in your broker:

```
execute procedure json2mqtt('{"operation":"insert", "table":"state", "owner":"informix", "database":"stores_demo", "txnid":12124695617764, "commit_time":1621529490, "rowdata":{"code":"53", "sname":"ES"}}');
execute procedure json2mqtt('{"operation":"update", "table":"state", "owner":"informix", "database":"stores_demo", "txnid":12124695625976, "commit_time":1621529490, "rowdata":{"code":"53", "sname":"UK"}, "before_rowdata":{"code":"53", "sname":"ES"}}');
execute procedure json2mqtt('{"operation":"delete", "table":"state", "owner":"informix", "database":"stores_demo", "txnid":12124695638244, "commit_time":1621529490, "rowdata":{"code":"53", "sname":"UK"}}');

```


# Define loppback replication

This readme is not intended to explain in detail what loopback replication is or how to define it properly. This are just notes to show some examples of commands and configuration steps.

If you are not already using ER, you will need two new dbspaces – with your preferred names – to hold the ER “syscdr” database and smart blobs which contain transaction contents, as was done for this article in the Docker container as follows:

```bash
eval cd $(dirname $(onstat -c ROOTPATH))
(umask 006 ; touch cdrdbs.000 cdrsbs.000)

onspaces -c -d cdrdbs -p $(pwd)/cdrdbs.000 -o 0 -s 204800
onspaces -c -S cdrsbs -p $(pwd)/cdrsbs.000 -o 0 -s 512000 -Df "AVG_LO_SIZE=2,LOGGING=ON"
```

Corresponding configuration parameters then need updating, together with two others as usually recommended:

```bash
cdr change config "CDR_DBSPACE cdrdbs"
cdr change config "CDR_QDATA_SBSPACE cdrsbs"
cdr change config "CDR_QUEUEMEM 262144"
cdr change config "CDR_SUPPRESS_ATSRISWARN 1,2,3"
```

If CDR_DBSPACE is set, the default for the above is in fact that and not “rootdbs” as stated. Specifically, setting CDR_QHDR_DBSPACE specifies the dbspace for the following “syscdr” tables (verified by testing):

```
blkdelete
control_send_stxn
trg_receive_stxn
trg_send_srep
trg_send_stxn
```

The next prerequisite step is to add a loopback connector (red) and ER group information (blue) in the “sqlhosts” file as described here and in the following example:
```
g_informix    group       -             -       i=1
informix      onsoctcp    *localhost    9088    g=g_informix

g_loopback    group       -             -       i=2
loopback      onsoctcp    *localhost    9090    g=g_loopback
```


Each asterisk instructs IDS to listen on all IP addresses available when started, which is not an ER requirement, but is often useful.

The $ONCONFIG file should be updated with the additional alias, for example:

```
DBSERVERNAME informix
DBSERVERALIASES loopback
```

A new listener thread can then be started and tested with:

```bash
onmode -P start loopback
echo | INFORMIXSERVER=loopback dbaccess sysmaster
```


ER can now be initiated with:

```
cdr define server -I g_informix
cdr define server -I g_loopback -S g_informix
```


# Create test environment

Create the test database and table

```sql

CREATE DATABASE IF NOT EXISTS testmqtt WITH LOG;

CREATE TABLE IF NOT EXISTS state(
  code INTEGER PRIMARY KEY,
  sname VARCHAR(40)
);

CREATE PROCEDURE IF NOT EXISTS json2mqtt(lvarchar)
  external name 'MqttPublisher.Json2Mqtt(java.lang.String)'
  language java;

grant execute on procedure json2mqtt(lvarchar) to public;

```

Define the ER replication pushing to MQTT broker. Shell commands to define and start the replicate are:

```bash
cdr define replicate repl_state -C always -S row -A -R \
    --jsonsplname=json2mqtt \
    "P testmqtt@g_informix:informix.state" "select * from informix.state" \
    "R testmqtt@g_loopback:informix.state" "select * from informix.state"

cdr start replicate repl_state
```

See our Loopback Replication article for a description of the standard options chosen above.

SQL for a basic test is:

```bash
INSERT INTO state VALUES (53, 'ES');
UPDATE state SET sname = 'UK' WHERE code = 53;
DELETE FROM state WHERE code = 53;
```



-- install the Java class Circle (customize the URL for your installation)

execute procedure install_jar("file:$INFORMIXDIR/PostCommitMQTT/MqttPublisher.jar", "postcommitmqtt_jar", 0);

-- register the Java class that maps to the circle UDT

--execute procedure setUDTExtName("circle", "Circle");

-- register the Java UDR

DROP PROCEDURE IF EXISTS json2mqtt;
CREATE PROCEDURE json2mqtt(lvarchar)
  external name 'MqttPublisher.Json2Mqtt(java.lang.String)'
  language java;

grant execute on procedure json2mqtt(lvarchar) to public;

execute procedure json2mqtt('{dbname:"midb", tabname:"22223"}');


drop procedure if exists json2mqtt;
create function json2mqtt(json) returns lvarchar external name 'MqttPublisher.processJson(MyJson)' language java;
execute function json2mqtt("{}"::JSON);


drop procedure if exists json2mqtt;
create procedure json2mqtt(json) external name 'MqttPublisher.processJson(com.informix.jdbc.IfxBSONObject)' language java;
execute procedure json2mqtt("{}"::JSON);




#1 - Check and recheck the configuration parameters in onconfig. Since
you have to bounce the server for them to take effect, you don't want to
be messing with them. The documentation on these is pretty good. I'll
comment just on a few of them.
VPCLASS jvp,num=1
You must have this line (it is usually commented out). This counts as a
CPU VP, sort of. On a single CPU machine, you will need NUMCPUVPS set to
1, but SINGLE_CPU_VP set to 0.
JVP* - these five parameters require you to type in the value of
$INFORMIXDIR before /extend ... They default to /usr/informix.
JVPJAVALIB - should be /lib/server (NOTE: no ending slash). For some
strange reason this defaults to /lib/ 
JVPCLASSPATH - make sure you change all the directories in the list to
the proper $INFORMIXDIR. I tripped on this twice.

# 3 - Make sure $INFORMIXDIR/extend/krakatoa/.jvpprops exists in the
directory you specified in ONCONFIG (usually
$INFORMIXDIR/extend/krakatoa). There is a .jvpprops.template that you
can copy. These configuration parameters are documented.
