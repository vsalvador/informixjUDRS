# Internal function

CREATE FUNCTION UUID() RETURNING CHAR(36) EXTERNAL NAME 'com.informix.judrs.IfxStrings.getUUID()' language java;
GRANT EXECUTE ON UUID TO PUBLIC;

SELECT UUID();


# External function

Created UUIDGenerator.java:
import java.util.UUID;

public class UUIDGenerator {
    public static String generateUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}

Compile it:
javac -source 1.8 -target 1.8 UUIDGenerator.java

Create jar file:
jar cf UUIDGenerator.jar UUIDGenerator.class

SQL file:
-- install
execute procedure sqlj.install_jar ("file://home/informix/profiles/uuid/UUIDGenerator.jar" , "UUIDGenerator_jar");

-- register function
create function generate_uuid() returning  CHAR(36) external name "UUIDGenerator_jar:UUIDGenerator.generateUUID" language JAVA;

-- use it
SELECT generate_uuid() FROM sysmaster:sysdual;
(expression)  7bdcfcfb-1a9f-4e13-98db-49d2c5932143

