
DBSCHEMA Schema Utility       INFORMIX-SQL Version 14.10.FC13W1

# Dbspace 1 -- Chunk 1
# onspaces -c -d rootdbs -k 2 -p /home/informix/ol_informix1410/dbspaces/rootdbs -o 0 -s 149504 -ef 500 -en 400

# Dbspace 2 -- Chunk 2
onspaces -c -P plog -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_plog_p_1 -o 0 -s 65536

# Dbspace 3 -- Chunk 3
onspaces -c -d llog -k 2 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_llog_p_1 -o 0 -s 273774 -ef 100 -en 100

# Dbspace 4 -- Chunk 4
onspaces -c -d datadbs1 -k 2 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_datadbs1_p_1 -o 0 -s 65536 -ef 100 -en 100

# Dbspace 5 -- Chunk 5
onspaces -c -d datadbs2 -k 2 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_datadbs2_p_1 -o 0 -s 65536 -ef 100 -en 100

# Dbspace 6 -- Chunk 6
onspaces -c -d datadbs3 -k 2 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_datadbs3_p_1 -o 0 -s 65536 -ef 100 -en 100

# Dbspace 7 -- Chunk 7
onspaces -c -d data8dbs1 -k 8 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_data8dbs1_p_1 -o 0 -s 65536 -ef 400 -en 400

# Dbspace 8 -- Chunk 8
onspaces -c -d data8dbs2 -k 8 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_data8dbs2_p_1 -o 0 -s 65536 -ef 400 -en 400

# Dbspace 9 -- Chunk 9
onspaces -c -d data8dbs3 -k 8 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_data8dbs3_p_1 -o 0 -s 65536 -ef 400 -en 400

# Dbspace 10 -- Chunk 10
onspaces -c -d tmpdbspace -k 8 -t -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_tmpdbspace_p_1 -o 0 -s 65536

# Dbspace 11 -- Chunk 11
onspaces -c -S sbspace1 -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_sbspace1_p_1 -o 0 -s 65536 -Ms 872

# Dbspace 12 -- Chunk 12
onspaces -c -S tmpsbspace -t -p /home/informix/ol_informix1410/dbspaces/ol_informix1410_tmpsbspace_p_1 -o 0 -s 65536 -Ms 872

# Physical Log 
onparams -p -s 65430 -d plog -y

# Store pre-existing logical logs information before create new logical logs 
dbaccess sysadmin << END 
CREATE TABLE llog (log smallint, flags  smallint); 
INSERT INTO llog SELECT number, flags FROM sysmaster:syslogfil; 
END

# Logical Log 1
onparams -a -d llog -s 6540

# Logical Log 2
onparams -a -d llog -s 6540

# Logical Log 3
onparams -a -d llog -s 6540

# Logical Log 4
onparams -a -d llog -s 6540

# Logical Log 5
onparams -a -d llog -s 6540

# Logical Log 6
onparams -a -d llog -s 6540

# Logical Log 7
onparams -a -d llog -s 6540

# Logical Log 8
onparams -a -d llog -s 6540

# Logical Log 9
onparams -a -d llog -s 6540

# Logical Log 10
onparams -a -d llog -s 6540

# Logical Log 11
onparams -a -d llog -s 6540

# Logical Log 12
onparams -a -d llog -s 6540

# Logical Log 13
onparams -a -d llog -s 6540

# Logical Log 14
onparams -a -d llog -s 6540

# Logical Log 15
onparams -a -d llog -s 6540

# Logical Log 16
onparams -a -d llog -s 6540

# Logical Log 17
onparams -a -d llog -s 6540

# Logical Log 18
onparams -a -d llog -s 6540

# Logical Log 19
onparams -a -d llog -s 6540

# Logical Log 20
onparams -a -d llog -s 6540

# Logical Log 21
onparams -a -d llog -s 6540

# Logical Log 22
onparams -a -d llog -s 6540

# Logical Log 23
onparams -a -d llog -s 6540

# Logical Log 24
onparams -a -d llog -s 6540

# Logical Log 25
onparams -a -d llog -s 6540

# Logical Log 26
onparams -a -d llog -s 6540

# Logical Log 27
onparams -a -d llog -s 6540

# Logical Log 28
onparams -a -d llog -s 6540

# Logical Log 29
onparams -a -d llog -s 6540

# Logical Log 30
onparams -a -d llog -s 6540

# Logical Log 31
onparams -a -d llog -s 6540

# Logical Log 32
onparams -a -d llog -s 6540

# Logical Log 33
onparams -a -d llog -s 6144

# Logical Log 34
onparams -a -d llog -s 6144

# Logical Log 35
onparams -a -d llog -s 6144

# Logical Log 36
onparams -a -d llog -s 6144

# Logical Log 37
onparams -a -d llog -s 6144

# Logical Log 38
onparams -a -d llog -s 6144

# Logical Log 39
onparams -a -d llog -s 6144

# Logical Log 40
onparams -a -d llog -s 6144

# Drop all pre-existing logical logs 
onmode -c
 
dbaccess sysadmin << END 
SELECT TASK ('drop log', log) FROM sysadmin:llog 
WHERE sysmaster:bitval(flags,'0x02')==0; 
END
 
onmode -c
 
dbaccess sysadmin << END 
SELECT TASK('onmode', 'l') FROM sysmaster:syslogfil 
WHERE chunk = 1 AND sysmaster:bitval(flags,'0x02')>0; 
END
 
onmode -c
 
dbaccess sysadmin << END 
SELECT TASK ('drop log', log) FROM sysadmin:llog 
WHERE sysmaster:bitval(flags,'0x02')==1; 
 
DROP TABLE sysadmin:llog; 
END
